import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectItem, SelectContent, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function CotizadorEncomiendas() {
  const [largo, setLargo] = useState(0);
  const [ancho, setAncho] = useState(0);
  const [alto, setAlto] = useState(0);
  const [pesoBruto, setPesoBruto] = useState(0);
  const [ciudad, setCiudad] = useState("PRINCIPAL");
  const [nombreProducto, setNombreProducto] = useState("");
  const [cliente, setCliente] = useState("");
  const [cantidad, setCantidad] = useState(1);
  const [resultados, setResultados] = useState([]);
  const [resumenActivo, setResumenActivo] = useState("resumen1");
  const [error, setError] = useState("");

  const redondear = (valor) => {
    const decimal = valor % 1;
    const entero = Math.floor(valor);
    const base = Math.floor(decimal * 100);
    const unidad = base % 10;
    const decena = Math.floor(base / 10);

    let nuevoDecimal = decena * 10;
    if (unidad >= 1 && unidad <= 4) nuevoDecimal = decena * 10;
    else if (unidad >= 5 && unidad <= 9) nuevoDecimal = (decena + 1) * 10;

    const redondeado = entero + nuevoDecimal / 100;
    return redondeado.toFixed(2);
  };

  const agregarProducto = () => {
    if (!nombreProducto || !cliente || alto <= 0 || ancho <= 0 || largo <= 0 || pesoBruto <= 0 || cantidad <= 0) {
      setError("Por favor complete todos los campos correctamente antes de agregar el producto.");
      return;
    }
    setError("");

    const pesoVolumetrico = (largo * ancho * alto) / 7000;
    const pesoFacturable = Math.max(pesoVolumetrico, pesoBruto);

    let precioBase = 0;
    let valorKgAdicional = 0;

    if (pesoFacturable <= 10) {
      if (ciudad === "PRINCIPAL") precioBase = 2.60;
      else if (ciudad === "SECUNDARIA") precioBase = 3.00;
      else if (ciudad === "ESPECIAL") precioBase = 3.50;
    } else {
      if (ciudad === "SECUNDARIA") {
        precioBase = 4.31;
        valorKgAdicional = 0.39;
      } else if (ciudad === "PRINCIPAL") {
        precioBase = 3.88;
        valorKgAdicional = 0.35;
      } else if (ciudad === "ESPECIAL") {
        precioBase = 5.18;
        valorKgAdicional = 0.43;
      }
    }

    const excesoKg = Math.max(pesoFacturable - 20, 0);
    const unitario = parseFloat(redondear(precioBase + excesoKg * valorKgAdicional));
    const costoTotal = parseFloat(redondear(unitario * cantidad));

    const pvpUnitario = parseFloat(redondear(unitario * 1.35));
    const pvpTotal = parseFloat(redondear(pvpUnitario * cantidad));
    const utilidadUnit = parseFloat(redondear(pvpUnitario - unitario));
    const utilidadTotal = parseFloat(redondear(utilidadUnit * cantidad));

    const nuevoProducto = {
      nombreProducto,
      ciudad,
      medidas: `AL:${alto}, AN:${ancho}, LA:${largo}`,
      pesoBruto: pesoBruto.toFixed(2),
      pesoVolumetrico: pesoVolumetrico.toFixed(2),
      pesoFacturable: pesoFacturable.toFixed(2),
      cantidad,
      unitario: unitario.toFixed(2),
      costoTotal: costoTotal.toFixed(2),
      pvpUnitario: pvpUnitario.toFixed(2),
      pvpTotal: pvpTotal.toFixed(2),
      utilidadUnit: utilidadUnit.toFixed(2),
      utilidadTotal: utilidadTotal.toFixed(2),
      id: Date.now(),
      cliente: cliente,
    };

    setResultados([...resultados, nuevoProducto]);
    setNombreProducto("");
    setLargo(0);
    setAncho(0);
    setAlto(0);
    setPesoBruto(0);
    setCantidad(1);
    setCiudad("PRINCIPAL");
  };

  const eliminarProducto = (id) => {
    setResultados(resultados.filter((item) => item.id !== id));
  };

  const eliminarTodo = () => {
    setResultados([]);
  };

  const sumar = (campo) => resultados.reduce((acc, item) => acc + parseFloat(item[campo] || 0), 0);

  return <div>Cotizador Encomiendas</div>;
}
